configuration TestPsFunction
{
	$i=0
	while ($i -lt 50) {
		date >> C:\windows\temp\0-test-PS-dsc.txt
		echo "i = $i"
		$i++
	}
	Node localhost
	{
		LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
	}
}