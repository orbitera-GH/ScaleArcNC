﻿configuration CreateADBDC 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xDisk, cDisk
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
   $user="SC\harnas"
$strPass = ConvertTo-SecureString -String "Qwerty12" -AsPlainText -Force
$Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ($user, $strPass)
echo "#### START ####" >> c:\windows\temp\0_BDC_log.txt
Install-ADDSDomainController -InstallDns -Credential $Cred -DomainName "SC.prv" -SafeModeAdministratorPassword $strPass -Force -SkipPreChecks >> c:\windows\temp\0_BDC_log.txt
echo "#### STOP ####" >> c:\windows\temp\0_BDC_log.txt
   
    Node localhost
    {
        
        LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
   }
} 
