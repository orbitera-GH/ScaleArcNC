﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InteraceAlias=$($Interface.Name)
#Import-Module ServerManager ; Install-WindowsFeature AD-Domain-Services, rsat-adds -IncludeAllSubFeature ; Install-WindowsFeature -name NET-Framework-Core -IncludeAllSubFeature
Import-Module ServerManager ; Install-ADDSForest -DomainName "SC.prv" -SafeModeAdministratorPassword (convertto-securestring P@ssw0rd -asplaintext -force) -DomainMode Win2012 -DomainNetbiosName "SC" -ForestMode Win2012 -Confirm:$false -Force
    Node localhost
    {
        
        LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
   }
} 